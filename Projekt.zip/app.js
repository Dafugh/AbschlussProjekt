//Get NodeJs modules
var express = require('express');
var app = express();
var http = require('http');
const bodyParser = require('body-parser');
const mysql = require('mysql');
var cookieParser = require('cookie-parser');

var server = http.createServer(app);
var io = require('socket.io').listen(server);

app.set('views', './views');
app.set('view engine', 'pug');

app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.get('/', (request, response) =>  response.sendFile(`${__dirname}/Index/index.html`));
app.use('/', express.static(__dirname + '/index'));
app.use('/styles', express.static(__dirname + '/styles'));
app.use('/js', express.static(__dirname + '/js'));
app.use('/template', express.static(__dirname + '/template'));
app.use('/views',express.static(__dirname +'/views'));
app.use('/index',express.static(__dirname +'/Index'));

function createId() { //Six digit number for the UID of the room
    var randomNumber = Math.random();
    var  decimaluid= randomNumber *100000;
    var uid = Math.trunc(decimaluid);
    return uid;
} 
var database = mysql.createConnection({ 
    host: "localhost",
    port: "3309",
    user: "projektadmin",
    password: "adminprojekt",
    database: "poker"
})
function insertIdToDatabase(id) {
    database.query("INSERT INTO `Room` VALUES ('"+id+"')", function(err, res) {
         if(err) throw err;
         console.log("Successfully inserted id " + id);
    })
}
function insertUserName(username,id) {
    database.query("INSERT INTO `Users` VALUES ('"+username+"','"+id+"')", function(err, res) {
        if(err) throw err;
        console.log("Successfully inserted User " + username + " on roomid " + id);
   })
}
function getUserName(id) {
    var username = [];
    database.query("SELECT * FROM `Users` ", function(err, res) {
        if(err) throw err;
        res.forEach(function(element) {
            username = res;
        });
        username = res;
        console.log(username);
   })
   return username;
}
function getAllUserVotes(id){
    var username = [];
    database.query("SELECT Username, Vote FROM `Votes` WHERE room_id = '"+id+"'", function(err, res) {
        if(err) throw err;
        var userstring = []
        for(i = 0; i < res.length; i++) {
            //console.log("Test:" + res[0].Username);
            userstring.push({Username: res[i].Username,Vote: res[i].Vote});
            console.log(userstring);
        }
        username = userstring;
   })
   
}
function addDefaultVote(username,id, callback) {
    database.query("INSERT INTO Votes(Username, room_id) VALUES('"+username+"', '"+id+"') ON DUPLICATE KEY UPDATE Username = '"+username+"', room_id = '"+id+"'", function(err, res) {
         if(err) throw err;
        callback();
    })
    
}
function addOrUpdateVote(username,vote,roomid,callback) {
    database.query("INSERT INTO Votes VALUES('"+username+"','"+vote+"','"+roomid+"') ON DUPLICATE KEY UPDATE Username = '"+username+"', Vote = '"+vote+"', room_id = '"+roomid+"'", function(err, res) {
    //database.query("UPDATE Votes SET Username = 'Test54548', Vote ='Peter' WHERE Username = 'Test54548'", function(err, res) {
        if(err) throw err;
        console.log("Successfully inserted Vote: " + vote + " on roomid " + username);
    }) 
    callback();
}
//RESTAPI
app.post('/Index/data', (req, res) => {
    const roomId = createId();
    const username = req.body.Input_UserName;
    insertIdToDatabase(roomId);
    insertUserName(username,roomId); 
    res.redirect(`/room/${roomId}/${username}`);
});
app.get('/room/:id', (req, res) => {
    var id = {
        id : req.params.id
    }
    res.cookie('ID',id);
    res.sendFile(`${__dirname}/Index/roomconnect.html`);
});
app.post('/Index/join', (req, res) => {
    const username = req.body.Input_UserNameJoin;
    const roomId = req.cookies.ID.id;
    if(username != "undefined" && roomId !="undefined") insertUserName(username,roomId);
    res.redirect(`/room/${roomId}/${username}`);
});
app.get('/room/:id/:username', (req, res) => {
    const id = req.params.id;
    res.sendFile(`${__dirname}/template/roomtemplate.html`, function(err, res) {

    });
    io.on('connection', function(socket) {
        console.log("ID: " + socket.id);
        database.query("INSERT INTO Votes(Username, room_id) VALUES('"+req.params.username+"', '"+req.params.id+"') ON DUPLICATE KEY UPDATE Username = '"+req.params.username+"', room_id = '"+req.params.id+"'", function(err, res) {
            if(err) throw err;
            database.query("SELECT * FROM `Votes` WHERE room_id = '"+id+"'", function(error, result) {
                if(error) throw error;
                console.log(result);
                io.sockets.emit('Table', result);
           })
       })
        socket.on('card_Choosen', function(data){
            console.log("2 ID: " + data.vote);
            if(req.params.id == data.roomid) {
                database.query("INSERT INTO Votes VALUES('"+data.username+"','"+data.vote+"','"+data.roomid+"')ON DUPLICATE KEY UPDATE Vote = '"+data.vote+"'", function(err, res) {
                    if(err) throw err;
                    console.log("Successfully inserted Vote: " + data.vote + " on roomid " + data.roomid);
                    database.query("SELECT * FROM `Votes` WHERE room_id = '"+id+"'", function(error, result) {
                        if(error) throw error;
                        io.sockets.emit('Table', result);
                    })
                })
            }
        })
    })
   
})
server.listen(3000);

